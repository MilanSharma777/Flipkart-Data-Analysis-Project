# Power BI Dashboard — Step-by-Step Build Guide

Use `flipkart_sales_clean.csv` (or the Clean_Data sheet from the Excel file) as your source.

## Step 1: Load & Model Data
1. Power BI Desktop → **Get Data → Text/CSV** → select `flipkart_sales_clean.csv`.
2. In Power Query Editor, confirm data types: `Order Date` = Date, `Sales`/`Profit`/`Discount` = Decimal Number, `Quantity` = Whole Number.
3. Click **Close & Apply**.
4. Go to **Model view** and create a proper **Date Table** for time intelligence:
   ```
   DateTable = CALENDAR(MIN(flipkart_sales[Order Date]), MAX(flipkart_sales[Order Date]))
   ```
   Mark it as a Date Table (Table tools → Mark as Date Table), then relate `DateTable[Date]` → `flipkart_sales[Order Date]`.

## Step 2: Create Core DAX Measures

```DAX
Total Sales = SUM(flipkart_sales[Sales])
Total Profit = SUM(flipkart_sales[Profit])
Total Orders = COUNTROWS(flipkart_sales)
Avg Order Value = DIVIDE([Total Sales], [Total Orders])
Profit Margin % = DIVIDE([Total Profit], [Total Sales])
Unique Customers = DISTINCTCOUNT(flipkart_sales[Customer ID])
Cancelled Returned Orders =
    CALCULATE([Total Orders], flipkart_sales[Delivery Status] IN {"Cancelled","Returned"})
Cancellation Rate % = DIVIDE([Cancelled Returned Orders], [Total Orders])
Sales LY = CALCULATE([Total Sales], SAMEPERIODLASTYEAR('DateTable'[Date]))
Sales YoY % = DIVIDE([Total Sales] - [Sales LY], [Sales LY])
```

## Step 3: Build the Dashboard Pages

**Page 1 — Executive Overview**
- 4-5 **Card** visuals: Total Sales, Total Profit, Total Orders, Avg Order Value, Profit Margin %
- **Clustered Bar Chart**: Sales by Product Category
- **Donut Chart**: Delivery Status breakdown
- **Line Chart**: Monthly Sales trend (X = Order Month, Y = Total Sales)
- **Map (Filled or Bubble)**: Total Sales by State

**Page 2 — Category & Product Deep Dive**
- **Table/Matrix**: Category × Profit Margin % × Total Sales × Orders, conditional formatting on margin
- **Treemap**: Product Name sized by Sales, colored by Category
- **Slicers**: Product Category, Payment Method

**Page 3 — Customer & Operations**
- **Bar Chart**: Top 10 Customers by Sales
- **KPI visual**: Cancellation/Return rate with a target line (e.g., target <12%)
- **Stacked Bar**: Delivery Status by State (spot regional fulfillment problems)
- **Slicers**: Date range, State

## Step 4: Polish
- Apply a consistent theme (View → Themes) — Flipkart's blue/yellow works well as an accent palette.
- Add a title text box and your name/date in the footer (good for portfolio screenshots).
- Use bookmarks for "story mode" if presenting live.
- Publish to Power BI Service (optional) and grab a shareable link.

---

# Resume Bullet Points

- Built an end-to-end sales analytics pipeline on a 6,000-row Flipkart-style e-commerce dataset using Python, SQL, Excel, and Power BI — covering data cleaning, EDA, KPI design, and dashboarding.
- Cleaned and standardized a messy raw dataset (inconsistent date formats, duplicate records, missing values) using Python/pandas, achieving 100% data completeness across 18 fields.
- Wrote 15+ SQL queries to extract business insights on revenue, profitability, customer retention, and delivery performance across 7 product categories and 12 states.
- Designed an interactive Power BI dashboard with category, geographic, and time-trend views, surfacing a 17% order cancellation/return rate representing ~Rs. 1.85 Cr of at-risk revenue.
- Delivered actionable business recommendations (retention strategy, fulfillment quality investigation) based on quantitative analysis of sales, profit margin, and discount-elasticity data.

---

# LinkedIn Post Draft

🛒 **New Project: End-to-End Flipkart Sales Analysis**

I built a full data analyst portfolio project covering the complete pipeline analysts use in real jobs:

📊 **Excel** – cleaned 6,000+ raw e-commerce orders (messy dates, duplicates, missing values) and built a live KPI dashboard with formulas + charts
🗄️ **SQL** – wrote 15+ queries answering real business questions (top categories, cancellation rates, customer retention, discount impact on margin)
📈 **Power BI** – built an interactive 3-page dashboard with DAX measures, time intelligence, and geographic visuals
🐍 **Python** – automated the data generation + cleaning pipeline with pandas

Key insight: 17% of orders were cancelled or returned, representing ~Rs. 1.85 Cr in at-risk revenue — the single biggest lever for improving profitability.

This project taught me that the hardest part of analytics isn't the chart — it's asking the right business question and tracing it back through messy real-world data.

#DataAnalytics #PowerBI #SQL #Excel #Python #PortfolioProject

---

# Interview Prep — Likely Questions & How to Answer

**Q: Walk me through your project.**
"I built an end-to-end analysis on a Flipkart-style dataset of 6,000 orders. I started with intentionally messy raw data — inconsistent date formats, ~70 duplicate rows, missing values, and data-entry typos — and documented a full cleaning pipeline in Python/pandas. I then wrote SQL queries to answer business questions around revenue, profitability, customer retention, and operational risk, and built an interactive Power BI dashboard with category, geographic, and trend views. The standout insight was that cancelled/returned orders represented about 17% of volume and Rs. 1.85 Cr of revenue — which became my key recommendation."

**Q: How did you handle missing/dirty data?**
"I had four data quality issues: inconsistent date formats, ~70 exact duplicate rows, missing values in Profit/Discount/Payment Method/City, and a few negative-quantity entry errors. I parsed dates with a fallback format-detection function, dropped exact duplicates, used `.abs()` for the quantity typos, and for missing Profit I imputed using the median profit margin of that product's category — so the imputation stayed business-realistic instead of distorting category-level margins."

**Q: Why did you choose those specific KPIs?**
"Total Sales and Profit show scale and health; AOV and Orders show transaction-level behavior; Profit Margin % normalizes for category mix; and Cancellation/Return Rate is an operational health metric — most dashboards stop at revenue, but I wanted at least one KPI pointing to a controllable risk, not just a vanity metric."

**Q: What would you do differently with real data / more time?**
"I'd add cohort-based retention analysis, look at delivery-time-to-cancellation correlation, and if I had cost data, build a true contribution margin by SKU instead of a flat profit field."

**Q: Explain a SQL window function you used.**
Walk through the `LAG()` YoY growth query or the `COUNT(*) OVER()` percentage-of-total query in `sql_analysis_queries.sql`.

**Q: How would this dashboard change for a non-technical stakeholder vs. a category manager?**
"Executive view stays at Page 1 — sales/profit/trend. A category manager would want Page 2's product-level treemap and margin table. I built separate pages for exactly that reason — different audiences need different depth."
