/* ============================================================
   FLIPKART SALES ANALYSIS — SQL QUERIES
   Table: flipkart_sales  (load Clean_Data sheet / flipkart_sales_clean.csv)
   Engine: MySQL / PostgreSQL compatible (minor tweaks noted where needed)
   ============================================================ */

-- 0. TABLE CREATION (run this first if loading the CSV into SQL)
CREATE TABLE flipkart_sales (
    order_id            VARCHAR(20),
    order_date          DATE,
    order_year          INT,
    order_month         VARCHAR(15),
    order_month_num     INT,
    customer_id         VARCHAR(20),
    product_category    VARCHAR(50),
    product_name        VARCHAR(100),
    state               VARCHAR(50),
    city                VARCHAR(50),
    quantity            INT,
    sales               DECIMAL(12,2),
    discount            DECIMAL(5,2),
    profit              DECIMAL(12,2),
    profit_margin_pct   DECIMAL(6,2),
    avg_order_value     DECIMAL(12,2),
    payment_method      VARCHAR(30),
    delivery_status     VARCHAR(20)
);

-- Use LOAD DATA INFILE (MySQL) or \copy (Postgres) to import flipkart_sales_clean.csv


/* ============================================================
   1. CORE KPIs
   ============================================================ */

-- 1.1 Total Sales, Total Profit, Total Orders, Average Order Value
SELECT
    ROUND(SUM(sales), 2)            AS total_sales,
    ROUND(SUM(profit), 2)           AS total_profit,
    COUNT(order_id)                 AS total_orders,
    ROUND(AVG(sales), 2)            AS avg_order_value,
    ROUND(SUM(profit) / SUM(sales) * 100, 2) AS overall_profit_margin_pct
FROM flipkart_sales;

-- 1.2 Total unique customers
SELECT COUNT(DISTINCT customer_id) AS unique_customers
FROM flipkart_sales;


/* ============================================================
   2. CATEGORY & PRODUCT LEVEL INSIGHTS
   ============================================================ */

-- 2.1 Top performing categories by sales
SELECT
    product_category,
    SUM(sales)   AS total_sales,
    SUM(profit)  AS total_profit,
    COUNT(*)     AS orders,
    ROUND(SUM(profit) / SUM(sales) * 100, 2) AS profit_margin_pct
FROM flipkart_sales
GROUP BY product_category
ORDER BY total_sales DESC;

-- 2.2 Top 10 best-selling products by revenue
SELECT
    product_name,
    product_category,
    SUM(quantity)  AS units_sold,
    SUM(sales)     AS total_sales
FROM flipkart_sales
GROUP BY product_name, product_category
ORDER BY total_sales DESC
LIMIT 10;

-- 2.3 Categories with negative or thin profit margins (risk flag)
SELECT
    product_category,
    ROUND(SUM(profit) / SUM(sales) * 100, 2) AS profit_margin_pct
FROM flipkart_sales
GROUP BY product_category
HAVING ROUND(SUM(profit) / SUM(sales) * 100, 2) < 10
ORDER BY profit_margin_pct ASC;


/* ============================================================
   3. GEOGRAPHIC INSIGHTS
   ============================================================ */

-- 3.1 Sales by state, ranked
SELECT
    state,
    SUM(sales)  AS total_sales,
    SUM(profit) AS total_profit,
    COUNT(*)    AS orders
FROM flipkart_sales
GROUP BY state
ORDER BY total_sales DESC;

-- 3.2 Top 10 cities by sales
SELECT
    city,
    state,
    SUM(sales) AS total_sales,
    COUNT(*)   AS orders
FROM flipkart_sales
GROUP BY city, state
ORDER BY total_sales DESC
LIMIT 10;


/* ============================================================
   4. TIME-BASED TRENDS
   ============================================================ */

-- 4.1 Month-on-month sales trend
SELECT
    order_year,
    order_month_num,
    order_month,
    SUM(sales)  AS total_sales,
    SUM(profit) AS total_profit,
    COUNT(*)    AS orders
FROM flipkart_sales
GROUP BY order_year, order_month_num, order_month
ORDER BY order_year, order_month_num;

-- 4.2 Year-over-year growth (self-join / window function approach)
SELECT
    order_year,
    SUM(sales) AS yearly_sales,
    LAG(SUM(sales)) OVER (ORDER BY order_year) AS prev_year_sales,
    ROUND(
        (SUM(sales) - LAG(SUM(sales)) OVER (ORDER BY order_year))
        / LAG(SUM(sales)) OVER (ORDER BY order_year) * 100, 2
    ) AS yoy_growth_pct
FROM flipkart_sales
GROUP BY order_year
ORDER BY order_year;


/* ============================================================
   5. CUSTOMER INSIGHTS
   ============================================================ */

-- 5.1 Top 10 customers by lifetime spend
SELECT
    customer_id,
    SUM(sales)   AS lifetime_spend,
    COUNT(*)     AS total_orders,
    ROUND(AVG(sales), 2) AS avg_order_value
FROM flipkart_sales
GROUP BY customer_id
ORDER BY lifetime_spend DESC
LIMIT 10;

-- 5.2 Repeat customers vs one-time customers
SELECT
    CASE WHEN order_count = 1 THEN 'One-Time Customer' ELSE 'Repeat Customer' END AS customer_type,
    COUNT(*) AS num_customers
FROM (
    SELECT customer_id, COUNT(*) AS order_count
    FROM flipkart_sales
    GROUP BY customer_id
) t
GROUP BY customer_type;


/* ============================================================
   6. PAYMENT & DELIVERY INSIGHTS
   ============================================================ */

-- 6.1 Sales distribution by payment method
SELECT
    payment_method,
    COUNT(*)    AS orders,
    SUM(sales)  AS total_sales,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct_of_orders
FROM flipkart_sales
GROUP BY payment_method
ORDER BY total_sales DESC;

-- 6.2 Delivery status breakdown + cancellation/return rate
SELECT
    delivery_status,
    COUNT(*) AS orders,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct_of_total
FROM flipkart_sales
GROUP BY delivery_status
ORDER BY orders DESC;

-- 6.3 Revenue lost to cancelled/returned orders
SELECT
    ROUND(SUM(sales), 2) AS revenue_at_risk,
    COUNT(*) AS affected_orders
FROM flipkart_sales
WHERE delivery_status IN ('Cancelled', 'Returned');


/* ============================================================
   7. DISCOUNT IMPACT ANALYSIS
   ============================================================ */

-- 7.1 Does higher discount correlate with lower profit margin?
SELECT
    discount,
    COUNT(*)    AS orders,
    ROUND(AVG(profit_margin_pct), 2) AS avg_profit_margin_pct,
    SUM(sales)  AS total_sales
FROM flipkart_sales
GROUP BY discount
ORDER BY discount;

-- 7.2 Orders with discount >= 25% and negative profit (loss-making deep discounts)
SELECT
    product_category,
    COUNT(*) AS loss_making_orders,
    ROUND(SUM(profit), 2) AS total_loss
FROM flipkart_sales
WHERE discount >= 25 AND profit < 0
GROUP BY product_category
ORDER BY total_loss ASC;


/* ============================================================
   8. RFM-STYLE CUSTOMER SEGMENTATION (bonus / advanced)
   ============================================================ */

SELECT
    customer_id,
    DATEDIFF(CURRENT_DATE, MAX(order_date)) AS recency_days,
    COUNT(*)            AS frequency,
    SUM(sales)          AS monetary_value
FROM flipkart_sales
GROUP BY customer_id
ORDER BY monetary_value DESC
LIMIT 20;

-- Note: DATEDIFF syntax shown is MySQL. Postgres equivalent:
-- (CURRENT_DATE - MAX(order_date)) AS recency_days
