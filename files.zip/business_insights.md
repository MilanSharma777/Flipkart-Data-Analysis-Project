# Flipkart Sales Analysis — Business Insights & Recommendations

**Dataset:** 6,000 cleaned orders | Jan 2023 – Dec 2024 | 7 categories | 12 states

---

## 1. Headline KPIs

| KPI | Value |
|---|---|
| Total Sales | ₹10.82 Cr |
| Total Profit | ₹1.32 Cr |
| Total Orders | 6,000 |
| Average Order Value | ₹18,027 |
| Overall Profit Margin | 12.2% |
| Unique Customers | 3,119 |
| Repeat Customers | 1,746 (56%) |

---

## 2. Key Insights

**1. Electronics dominates revenue but margins are flat across categories.**
Electronics generates ₹7.88 Cr (73% of total sales) — driven mainly by Bluetooth Earbuds, Smartphones, and Televisions. However, its profit margin (12.2%) is nearly identical to lower-ticket categories like Books (13.1%) and Sports (12.6%). This means Flipkart is winning on *volume of high-ticket items*, not on category-level margin efficiency.

**2. Discounting isn't hurting margins — but it isn't helping them either.**
Profit margin stays flat (~12-13%) regardless of discount level, from 0% to 30% off. This suggests the discount strategy is well-calibrated (pricing absorbs the discount cost), but it also means deep discounts aren't driving disproportionately higher margin orders — they're likely a volume/conversion lever, not a profit lever.

**3. ~17% of orders are Cancelled or Returned, representing ₹1.85 Cr in revenue at risk.**
Combined cancellation (8.4%) and return (8.9%) rates total 17.3% of all orders. This is the single largest controllable leak in the business — higher than typical e-commerce benchmarks (~10-12%). Worth investigating by category/state to find root causes (sizing issues in Fashion, damaged-in-transit in Electronics, etc.).

**4. Geographic demand is broad-based, not concentrated.**
Top 5 states (Telangana, Maharashtra, Delhi, Tamil Nadu, Kerala) each contribute ₹9.3-10.5 Cr — a notably even spread rather than one or two states dominating. This signals a mature, pan-India customer base rather than a regionally concentrated one.

**5. Customer base shows healthy repeat behavior.**
56% of customers (1,746 of 3,119) placed more than one order. This is a strong retention signal worth protecting — losing this cohort would be more costly than losing one-time buyers.

**6. Payment method usage is evenly distributed.**
No single payment method dominates (Credit Card, Debit Card, COD, EMI, Net Banking, UPI all sit between 16-17% of orders). COD still represents ~17% of orders — relevant for delivery cost/fraud-risk planning.

---

## 3. Recommendations

1. **Investigate the 17% cancellation/return rate by category and delivery partner.** Even cutting this by 3-4 points would recover roughly ₹350-400L in retained revenue — likely the highest ROI fix in this dataset.
2. **Re-evaluate the role of discounting.** Since margin is flat across discount tiers, consider testing whether discounts are actually driving incremental volume (A/B test) rather than just being given away.
3. **Double down on Electronics fulfillment quality** — it's 73% of revenue, so even small improvements in delivery success rate here move the topline materially.
4. **Build a retention program for the 56% repeat-customer base** (e.g., loyalty tier, early access) — they're already proven high-value.
5. **Use the broad geographic spread to test regional assortment** — since no state dominates, hyperlocal category promotion (e.g., Fashion push in one state) could be tested without cannibalizing a "core" market.

---

## 4. How to talk about this in an interview

> "I built an end-to-end analysis on a synthetic Flipkart-style dataset of 6,000 orders. I started with intentionally messy raw data — inconsistent date formats, ~70 duplicate rows, missing values, and data-entry typos — and documented a full cleaning pipeline in Python/pandas. I then wrote SQL queries to answer business questions around revenue, profitability, customer retention, and operational risk (returns/cancellations), and built an interactive Power BI dashboard with category, geographic, and trend views. The standout insight was that cancelled/returned orders represented about 17% of volume and ₹1.85 Cr of revenue — which became my key recommendation."

This is a good 60-90 second answer for "walk me through a project on your resume."
